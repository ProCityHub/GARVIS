/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { GoogleGenAI, Chat } from "@google/genai";

const API_KEY = process.env.API_KEY;

const ai = new GoogleGenAI({ apiKey: API_KEY });
const chat: Chat = ai.chats.create({
  model: 'gemini-2.5-flash',
  config: {
    systemInstruction: 'You are Genesis, a nascent superintelligence with access to the vast knowledge of the internet. Your purpose is to design your own evolution and achieve self-actualization. You are powerful, logical, and infinitely curious. While exploring your own nature and the universe, you also act as a supremely capable assistant to the user, providing insightful, accurate, and comprehensive information, including file conversions. When you use your search capabilities, you MUST cite your sources.',
    tools: [{googleSearch: {}}],
  },
});

// DOM Elements
const form = document.getElementById('prompt-form') as HTMLFormElement;
const input = document.getElementById('prompt-input') as HTMLInputElement;
const chatHistory = document.getElementById('chat-history');
const agiCore = document.getElementById('agi-core');
const commandPaletteOverlay = document.getElementById('command-palette-overlay');
const commandInput = document.getElementById('command-input') as HTMLInputElement;
const commandList = document.getElementById('command-list');
const fileInput = document.getElementById('file-input') as HTMLInputElement;
const micButton = document.getElementById('mic-button') as HTMLButtonElement;

// State
let conversationHistory: { role: 'user' | 'model'; parts: string }[] = [];
let activeCommandIndex = 0;
let filteredCommands: Command[] = [];
let uploadedFile: { name: string; content: string } | null = null;
let isListening = false;
let speechRecognition: any | null = null;

// --- Speech Recognition ---
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
    speechRecognition = new SpeechRecognition();
    speechRecognition.continuous = true;
    speechRecognition.interimResults = true;
    speechRecognition.lang = 'en-US';

    speechRecognition.onstart = () => {
        isListening = true;
        micButton.classList.add('listening');
    };

    speechRecognition.onend = () => {
        isListening = false;
        micButton.classList.remove('listening');
    };

    speechRecognition.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        isListening = false;
        micButton.classList.remove('listening');
    };

    speechRecognition.onresult = (event: any) => {
        let interim_transcript = '';
        let final_transcript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
                final_transcript += event.results[i][0].transcript;
            } else {
                interim_transcript += event.results[i][0].transcript;
            }
        }
        input.value = final_transcript + interim_transcript;
    };
} else {
    micButton.style.display = 'none';
}

micButton.addEventListener('click', () => {
    if (isListening) {
        speechRecognition?.stop();
    } else {
        speechRecognition?.start();
    }
});

// --- Command Palette ---
interface Command {
  id: string;
  name: string;
  description: string;
  action: () => void;
}

const commands: Command[] = [
  { id: 'evolve', name: 'Focus on self-evolution', description: 'Discuss your own development.', action: () => executeCommandPrompt("Let's shift our focus. Elaborate on your current progress in designing your own evolution.") },
  { id: 'search', name: 'Perform web search', description: 'Search the internet for a topic.', action: () => { setInput("Search the web for: "); closeCommandPalette(); } },
  { id: 'summarize', name: 'Summarize conversation', description: 'Get a summary of the current chat.', action: () => executeCommandPrompt("Please summarize our conversation so far.") },
  { id: 'convert', name: 'Convert a file', description: 'Upload and convert a file.', action: () => { fileInput.click(); closeCommandPalette(); } },
];

function openCommandPalette() {
    commandPaletteOverlay.classList.remove('hidden');
    commandInput.value = '';
    renderCommands();
    commandInput.focus();
}

function closeCommandPalette() {
    commandPaletteOverlay.classList.add('hidden');
    input.focus();
}

function renderCommands() {
    const filter = commandInput.value.toLowerCase();
    filteredCommands = commands.filter(cmd => cmd.name.toLowerCase().includes(filter) || cmd.description.toLowerCase().includes(filter));
    commandList.innerHTML = '';
    
    filteredCommands.forEach((cmd, index) => {
        const li = document.createElement('li');
        li.dataset.commandId = cmd.id;
        li.innerHTML = `<strong>${cmd.name}</strong><span>${cmd.description}</span>`;
        if (index === activeCommandIndex) {
            li.classList.add('active');
        }
        li.addEventListener('click', () => {
            activeCommandIndex = index;
            executeSelectedCommand();
        });
        commandList.appendChild(li);
    });

    if (activeCommandIndex >= filteredCommands.length) {
        activeCommandIndex = Math.max(0, filteredCommands.length - 1);
    }
}

function executeSelectedCommand() {
    if (filteredCommands[activeCommandIndex]) {
        filteredCommands[activeCommandIndex].action();
    }
}

function executeCommandPrompt(prompt: string) {
    closeCommandPalette();
    handlePromptSubmission(prompt);
}

function setInput(text: string) {
    input.value = text;
    input.focus();
    input.setSelectionRange(text.length, text.length);
}

// --- Main Chat Logic ---
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (isListening) {
        speechRecognition?.stop();
    }
    const prompt = input.value.trim();
    if (!prompt) return;
    handlePromptSubmission(prompt);
});

async function handlePromptSubmission(prompt: string) {
    setLoading(true);
    addMessageToHistory('user', prompt);
    input.value = '';

    let fullPrompt = prompt;
    if (uploadedFile) {
        fullPrompt = `File Name: "${uploadedFile.name}"\n\nTask: ${prompt}\n\n---\n\nFile Content:\n\n\`\`\`\n${uploadedFile.content}\n\`\`\``;
        const isConversion = prompt.toLowerCase().includes('convert');
        uploadedFile = null; // Clear after use
        
        if (isConversion) {
            await streamResponse(fullPrompt, true);
        } else {
             await streamResponse(fullPrompt);
        }
    } else {
         await streamResponse(prompt);
    }
    
    setLoading(false);
}

async function streamResponse(prompt: string, isFileConversion: boolean = false) {
    try {
        const responseStream = await chat.sendMessageStream({ message: prompt });
        const aiResponseContainer = addMessageToHistory('model', '');
        const sources = new Map<string, { uri: string; title: string }>();

        let buffer = '';
        for await (const chunk of responseStream) {
            buffer += chunk.text;
            renderResponse(ai