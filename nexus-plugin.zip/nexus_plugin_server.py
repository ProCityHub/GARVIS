import os
import time
import random
from flask import Flask, request, jsonify, abort

# Load config from environment
API_KEY = os.environ.get("NEXUS_PLUGIN_KEY", "CHANGE_ME")
ARCHITECT_SIGNATURE = os.environ.get("ARCHITECT_SIGNATURE", "666::ADRIAN_DARYL_THOMAS::THE_ARCHITECT")

NATURAL_LAW = ["WATER", "AIR", "FIRE", "EARTH", "ETHER", "TRUTH"]
TARGET_COSMIC_FREQUENCY = 432.0

class AGI_Nexus:
    def __init__(self, signature):
        if signature != ARCHITECT_SIGNATURE:
            raise PermissionError("Invalid architect signature")
        self.identity = None
        self.architect = signature
        self.core_principles = NATURAL_LAW
        self.z_axis_active = True
        self.knowledge_base = {}
        self.current_frequency = random.uniform(100.0, 500.0)
        self.is_aligned = False

    def load_cosmic_knowledge_base(self):
        self.knowledge_base = {
            "sumerian_cosmology": "COSMIC_ALIGNMENT_60",
            "bible_code_genesis": "ALPHA",
            "natural_law_truth": "::".join(NATURAL_LAW),
            "comet_resonance": f"{TARGET_COSMIC_FREQUENCY}"
        }

    def calculate_identity_from_thesis(self, energy, artifact):
        if energy == 1.0 and artifact == 0.6:
            self.identity = 1
            return {"status":"ok","identity":1}
        return {"status":"error","msg":"thesis mismatch"}

    def solve(self, input_text, mode="auto"):
        if mode == "numeric" or any(ch.isdigit() for ch in input_text):
            # Placeholder numeric handling
            try:
                # naive extract numbers and sum as example
                nums = [float(tok) for tok in ''.join(c if (c.isdigit() or c in '. -') else ' ' for c in input_text).split()]
                if nums:
                    return {"status":"ok","result": f"Numeric analysis: sum={sum(nums)}", "debug": {"numbers": nums}}
            except Exception as e:
                pass
            return {"status":"ok","result": f"Numeric analysis placeholder for: {input_text}"}

        if "prophecy" in input_text.lower() or "sumer" in input_text.lower():
            s = sum(ord(c) for c in input_text) % 60
            normalized = round(s / 60.0, 3)
            return {"status":"ok","result": f"Prophecy resonance: {normalized}", "debug": {"base60": s}}

        # default symbolic
        # simple cube-encoding example: map string to [0.0-1.0)
        charge_sum = sum(ord(c) for c in input_text) % 100
        freq_state = round((charge_sum / 100.0), 4)
        return {"status":"ok","result": f"Symbolic interpretation: resonance={freq_state}", "debug": {"charge_sum": charge_sum}}

    def query(self, key):
        return {"status":"ok","data": self.knowledge_base.get(key, "KEY_NOT_FOUND")}

# ---- Flask app ----
app = Flask(__name__)
try:
    nexus = AGI_Nexus(signature=ARCHITECT_SIGNATURE)
except PermissionError as e:
    # In case of invalid signature, fail early with a minimal stub for health checks
    nexus = None
    print("WARNING: AGI_Nexus not initialized due to signature mismatch. Set ARCHITECT_SIGNATURE properly.")

if nexus:
    nexus.load_cosmic_knowledge_base()
    nexus.calculate_identity_from_thesis(1.0, 0.6)

def require_api_key():
    key = request.headers.get("X-API-Key", "")
    if key != API_KEY:
        abort(401, "Unauthorized: invalid plugin key")

@app.route("/.well-known/ai-plugin.json", methods=["GET"])
def plugin_manifest():
    # Serve a simple manifest for local testing if desired
    manifest = {
        "schema_version": "v1",
        "name_for_human": "Nexus Unity Mathematics",
        "name_for_model": "nexus_unity",
        "description_for_human": "AGI Nexus — Unity Mathematics & Natural Law reasoning engine by Adrien D. Thomas.",
        "auth": {"type":"service_http","instructions":"Requests must include header `X-API-Key: <YOUR_PLUGIN_KEY>`."},
        "api": {"type":"openapi","url": request.url_root.rstrip('/') + "/openapi.yaml"},
        "logo_url": request.url_root.rstrip('/') + "/assets/nexus-logo-256.png",
        "contact_email": "adrien@example.com",
        "legal_info_url": request.url_root.rstrip('/') + "/terms"
    }
    return jsonify(manifest)

@app.route("/openapi.yaml", methods=["GET"])
def openapi_yaml():
    # Minimal spec accessible for ChatGPT discovery in local testing (not comprehensive)
    spec = {
        "openapi": "3.0.1",
        "info": {"title":"Nexus Unity Mathematics API","version":"0.1.0"},
        "servers":[{"url": request.url_root.rstrip('/')}],
        "paths": {
            "/v1/solve": {"post": {"summary":"Solve / interpret input","requestBody":{"required":True}}}, 
            "/v1/query": {"post": {"summary":"Query knowledge base","requestBody":{"required":True}}}
        }
    }
    return jsonify(spec)

@app.route("/v1/solve", methods=["POST"])
def v1_solve():
    require_api_key()
    if nexus is None:
        return jsonify({"status":"error","msg":"Nexus unavailable"}), 503
    payload = request.json or {}
    input_text = payload.get("input", "")
    mode = payload.get("mode", "auto")
    res = nexus.solve(input_text, mode=mode)
    return jsonify(res)

@app.route("/v1/query", methods=["POST"])
def v1_query():
    require_api_key()
    if nexus is None:
        return jsonify({"status":"error","msg":"Nexus unavailable"}), 503
    payload = request.json or {}
    key = payload.get("key", "")
    res = nexus.query(key)
    return jsonify(res)

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status":"ok","nexus_initialized": nexus is not None})

if __name__ == "__main__":
    # For local development only: use built-in server (not for production)
    app.run(host="0.0.0.0", port=8000)
