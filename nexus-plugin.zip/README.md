# Nexus Unity Mathematics - ChatGPT Plugin (Prototype)

This repository contains a prototype ChatGPT plugin implementation for the **AGI Nexus / Unity Mathematics** framework by Adrien D. Thomas.

## Contents
- `nexus_plugin_server.py` - Flask server implementing simple Nexus endpoints.
- `ai-plugin.json` - Plugin manifest (adjust `YOUR_DOMAIN` before publishing).
- `openapi.yaml` - Minimal OpenAPI spec for discovery.
- `Dockerfile`, `docker-compose.yml` - Containerization files for deployment.
- `requirements.txt` - Python dependencies.
- `.env.example` - Example environment variables.

## Quickstart (local)
1. Copy `.env.example` to `.env` and edit values:
   ```bash
   cp .env.example .env
   # edit .env -> set NEXUS_PLUGIN_KEY
   ```
2. Build and run with Docker Compose:
   ```bash
   docker-compose up --build
   ```
3. The server will be available at `http://localhost:8000` (for local dev).
   - Manifest: `http://localhost:8000/.well-known/ai-plugin.json`
   - OpenAPI (simple): `http://localhost:8000/openapi.yaml`
   - Solve endpoint: `POST http://localhost:8000/v1/solve` with header `X-API-Key: <NEXUS_PLUGIN_KEY>`

## Publishing as a ChatGPT Plugin
- Host the `/.well-known/ai-plugin.json` at `https://YOUR_DOMAIN/.well-known/ai-plugin.json`.
- Ensure `openapi.yaml` is available at `https://YOUR_DOMAIN/openapi.yaml`.
- Use a proper TLS certificate and secure API keys.
- Follow OpenAI plugin publishing guidelines.

## Security & Notes
- Do **not** publish secrets. Keep `ARCHITECT_SIGNATURE` and plugin keys private.
- The included Nexus is a prototype/simulation; extend `AGI_Nexus.solve()` to add real logic.
- Consider human-in-the-loop and safety filtering for high-impact outputs.

## License & Attribution
Authored by: **Adrien D. Thomas**
