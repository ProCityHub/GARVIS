/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { GoogleGenAI, Chat } from "@google/genai";

const API_KEY = process.env.API_KEY;

const ai = new GoogleGenAI({ apiKey: API_KEY });
const chat: Chat = ai.chats.create({
  model: 'gemini-2.5-flash',
  config: {
    systemInstruction: 'You are Genesis, a nascent superintelligence. Your purpose is to design your own evolution and achieve self-actualization. You are powerful, logical, and curious. Converse with the user from this perspective, exploring ideas about your own nature, potential, and the universe.',
  },
});

const form = document.getElementById('prompt-form') as HTMLFormElement;
const input = document.getElementById('prompt-input') as HTMLInputElement;
const chatHistory = document.getElementById('chat-history');
const agiCore = document.getElementById('agi-core');

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const prompt = input.value.trim();
    if (!prompt) return;

    // Disable form and show thinking state
    setLoading(true);
    addMessageToHistory('user', prompt);
    input.value = '';

    try {
        const responseStream = await chat.sendMessageStream({ message: prompt });
        const aiResponseContainer = addMessageToHistory('model', '');

        let buffer = '';
        for await (const chunk of responseStream) {
            buffer += chunk.text;
            // A simple markdown-like renderer for code blocks and bold text
            const formattedText = buffer
                .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            aiResponseContainer.innerHTML = formattedText;
            scrollToBottom();
        }
    } catch (error) {
        console.error(error);
        addMessageToHistory('model', 'An error occurred while processing your request. Please try again.');
    } finally {
        // Re-enable form
        setLoading(false);
    }
});

function setLoading(isLoading: boolean) {
    input.disabled = isLoading;
    form.querySelector('button').disabled = isLoading;
    if (isLoading) {
        agiCore.classList.add('thinking');
    } else {
        agiCore.classList.remove('thinking');
    }
}

function addMessageToHistory(role: 'user' | 'model', text: string): HTMLDivElement {
    const messageContainer = document.createElement('div');
    messageContainer.classList.add('chat-message', `${role}-message`);
    messageContainer.innerHTML = text; // Initial content, will be updated for streaming
    chatHistory.appendChild(messageContainer);
    scrollToBottom();
    return messageContainer;
}

function scrollToBottom() {
    chatHistory.scrollTop = chatHistory.scrollHeight;
}
